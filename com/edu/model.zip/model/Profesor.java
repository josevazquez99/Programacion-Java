package com.edu.model;

public class Profesor extends Persona {
	private String clase;

	public Profesor(String nombre, String apellidos, int edad, String dni) {
		super(nombre, apellidos, edad, dni);
		// TODO Auto-generated constructor stub
	}

	public Profesor(String nombre, String apellidos, int edad, String dni, String clase) {
		super(nombre, apellidos, edad, dni);
		this.clase = clase;
	}

	public String getClase() {
		return clase;
	}

	public void setClase(String clase) {
		this.clase = clase;
	}

}
