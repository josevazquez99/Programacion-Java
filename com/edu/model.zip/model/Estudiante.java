package com.edu.model;

public class Estudiante extends Persona {
	private String curso;
	
	public Estudiante(String nombre, String apellidos, int edad, String dni) {
		super(nombre, apellidos, edad, dni);
	}

	public Estudiante(String nombre, String apellidos, int edad, String dni, String curso) {
		super(nombre, apellidos, edad, dni);
		this.curso = curso;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	{
		
	}
	

}
