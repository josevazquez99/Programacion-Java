package com.edu.model;

public class Delegado extends Estudiante {
	private boolean esDelegado;

	public Delegado(String nombre, String apellidos, int edad, String dni) {
		super(nombre, apellidos, edad, dni);
		// TODO Auto-generated constructor stub
	}

	public Delegado(String nombre, String apellidos, int edad, String dni, boolean esDelegado) {
		super(nombre, apellidos, edad, dni);
		this.esDelegado = esDelegado;
	}

	public boolean isEsDelegado() {
		return esDelegado;
	}

	public void setEsDelegado(boolean esDelegado) {
		this.esDelegado = esDelegado;
	}
	

}
