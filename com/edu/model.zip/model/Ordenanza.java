package com.edu.model;

public class Ordenanza extends Persona {
	private boolean nivelSuperior;
	private int nivel;

	public Ordenanza(String nombre, String apellidos, int edad, String dni) {
		super(nombre, apellidos, edad, dni);
	}

	public Ordenanza(String nombre, String apellidos, int edad, String dni, boolean nivelSuperior, int nivel) {
		super(nombre, apellidos, edad, dni);
		this.nivelSuperior = nivelSuperior;
		this.nivel = nivel;
	}

	public boolean isNivelSuperior() {
		if (nivel > 5) {
			nivelSuperior = true;
		} else {
			nivelSuperior = false;
		}
		return nivelSuperior;
	}

	public void setNivelSuperior(boolean nivelSuperior) {
		this.nivelSuperior = nivelSuperior;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

}
